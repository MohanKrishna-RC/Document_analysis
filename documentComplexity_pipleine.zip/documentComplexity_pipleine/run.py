import PyPDF2
import camelot
import chardet
import pdftotext
import os    
from PyPDF2 import PdfFileReader
from singleImageConverter import *
import shutil
import sys
from collections import Counter

def numPages(file):
	pdf = PdfFileReader(open(file,'rb'))
	return pdf.getNumPages()


def check(file):
	rawdata = open(file, "rb").read()
	result = chardet.detect(rawdata)
	charenc = result['encoding']
	return charenc

def writeTxt(file,mode,data):
	file1 = open(file,mode)
	file1.write(data) 

def deleting(folder):
    for filename in os.listdir(folder):
        file_path = os.path.join(folder, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            print('Failed to delete %s. Reason: %s' % (file_path, e))

ImageProblem = []
EncodeProblem = []
currupt = []
longFile = []


def extract_information_pdftotext(file, p):
	global ImageProblem
	global EncodeProblem
	global longFile

	# Load your PDF
	with open(file, "rb") as f:
		pdf = pdftotext.PDF(f)
	s = ""
	# How many pages?
	print("Page Length : ",len(pdf))

	if len(pdf) >= 400 :
		print("Very long file with 400+ pages")
		longFile.append(p)

	for page in pdf:
		writeTxt("output.txt","w", page)
		if page == "":
			if p not in ImageProblem:
				ImageProblem.append(p)
				return 0
				
		if check("output.txt") is None:
			if p not in EncodeProblem:
				EncodeProblem.append(p)
				return 0
				

output_dir = 'Image'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

file = os.listdir('PDF')


for p in file:
	imageFile = "PDF/"+p
	print(imageFile)
	if imageFile.endswith('.pdf'):
		try:
			s = extract_information_pdftotext(imageFile, p)
			if s !=0 :
				convert(imageFile)
		except pdftotext.Error:
			pass
		except:
			pass
	print()

		
print("Readable but not extractable files : ")
if len(ImageProblem) != 0:
	print(ImageProblem)
if len(EncodeProblem) != 0:
	print(EncodeProblem)
if len(currupt) != 0:
	print(currupt)

