
import os
from pdf2image import convert_from_path
from shutil import copyfile

from pdf2image.exceptions import (
	PDFInfoNotInstalledError,
	PDFPageCountError,
	PDFSyntaxError
)

def convert(filePath):
	if filePath.endswith('.pdf'):
		image = convert_from_path(filePath)
		name = filePath.split("/")[1].split(".")[0]
		for i, j in enumerate(image):
			j.save("Image/"+name+str(i)+".png", "PNG")
